﻿Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared

Public Class LapKasMasuk

    Private Sub LapKasMasuk_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class